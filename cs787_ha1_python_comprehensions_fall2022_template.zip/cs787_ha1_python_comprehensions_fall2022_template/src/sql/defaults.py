login_str = '{username}/{password}@artemis.vsnet.gmu.edu:1521/vse18c.vsnet.gmu.edu'
