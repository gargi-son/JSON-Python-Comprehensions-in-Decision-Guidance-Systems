def imply(lhs,rhs):
    return((not lhs) or rhs)

def queries(univDB):
    tables = univDB["tables"]
    department = tables["department"]
    course = tables["course"]
    prereq = tables["prereq"]
# class may be a reserved word - check
    class_ = tables["class"]
    faculty = tables["faculty"]
    student = tables["student"]
    enrollment = tables["enrollment"]
    transcript = tables["transcript"]

    def coursesTaken(student,dcode,cno):
        result = any([
                t["ssn"] == student["ssn"] and
                t["dcode"] == dcode and
                t["cno"] == cno and
                (t["grade"] == "A" or t["grade"] == "B")
                for t in transcript
            ])
        return result

    def checkAllPrereq(student,dcode,cno):
        result = all([
            coursesTaken(student,pre["pcode"],pre["pno"])
            for pre in prereq
            if pre["dcode"] == dcode and pre["cno"] == cno
        ])
        return result

# boolean queries
# replace placeholders (True) with a Boolean expression that correctly answers each corresponding query

#The student with ssn = 82 has taken the course “CS 530” (must be in Transcipts)
    boolQuery_a = any([ True
                for t in transcript
                if t["ssn"] == 82 and
                t["dcode"] == "CS" and
                t["cno"] == 530
            ])

#A student named “John Smith” has taken the course “CS 530” (must be in Transcipts).
    boolQuery_b = any([True
                for s in student
                if s["name"]=="John Smith"
                if any([
                (s["ssn"] == t["ssn"] and
                t["dcode"] == "CS" and
                t["cno"] == 530)
                for t in transcript
                ])
    ])

#All students named “John Smith” has taken the course “CS 530” (must be in Transcipts)

    boolQuery_c = all([True
                for s in student
                if s["name"]=="John Smith"
                if any([
                (s["ssn"] == t["ssn"] and
                t["dcode"] == "CS" and
                t["cno"] == 530)
                for t in transcript
                ])
    ])

    # print("*********************",boolQuery_c)
    # try1=[True
    #             for s in student
    #             for t in transcript
    #             if s["name"]=="John Smith"
    #             and s["ssn"] == t["ssn"] and
    #             t["dcode"] == "CS" and
    #             t["cno"] == 530
    # ]
    # print("#####################",try1)

#    all([True
#                for s in student
#                if s["name"] == "John Smith"
#                if any([
#                (s["ssn"] == t["ssn"] and
#                t["dcode"] == "CS" and
#                t["cno"] == 530)
#                for t in transcript
#                ])])

#The student with ssn = 82 has satisfied all prerequisites for each class she is enrolled in.
    boolQuery_d = any([True
                for s in student
                if s["ssn"]== 82 and
                not(any([e["class"] == c["class"] and
                e["ssn"] == s["ssn"] and
                not(checkAllPrereq(s, c["dcode"], c["cno"] ))
                for e in enrollment
                for c in class_]))]
                )


#Every student has satisfied all prerequisites each class she is enrolled in.
    boolQuery_e = not(any([en["ssn"] == stud["ssn"] and
                            en["class"] == c["class"] and
                            not(checkAllPrereq(stud,c["dcode"],c["cno"]))
                        for c in class_
                        for en in enrollment
                        for stud in student
        ]))

    #boolQuery_e = all([True
    #            for s in student
    #            if not(any([e["class"] == c["class"] and
    #            e["ssn"] == s["ssn"] and
    #            not(checkAllPrereq(s, c["dcode"], c["cno"] ))
    #            for e in enrollment
    #            for c in class_]))]
    #            )

#Every student who majors in “CS” has satisfied all prerequisites for each class she is enrolled in.
    boolQuery_f = not(any([e["ssn"] == s["ssn"] and
                e["class"] == c["class"] and
                s["major"]=="CS" and

    not(checkAllPrereq(s,c["dcode"],c["cno"]))
        for c in class_
        for e in enrollment
        for s in student
]))


#A student named “John Smith” is enrolled in a class for which he did satisfied all prerequisites.
    #satPrereq = [s for s in student
    #    if all([
    #    e["class"] == c["class"] and
    #    e["ssn"] == s["ssn"]  and
    #    ( checkAllPrereq(s, c["dcode"], c["cno"] ))
    #    for e in enrollment
    #    for c in class_])]

    boolQuery_g = any([True
                    for s in student
                    if s["name"] == "John Smith" and
                    any(
                    s["ssn"] == e["ssn"] and
                    e["class"] == c["class"] and
                    (checkAllPrereq(s, c["dcode"], c["cno"] ))
                    for e in enrollment
                    for c in class_
                    )
                    ])

    #any([True
    #            for s in student
    #            if s["name"]== "John Smith" and
    #            (not(any(
    #            [e["class"] == c["class"] and
    #            e["ssn"] == s["ssn"] and
    #            not(checkAllPrereq(s, c["dcode"], c["cno"] ))
    #            for e in enrollment
    #            for c in class_
#])))


    #any([True
    #    for s in satPrereq
    #    if s["name"]=="John Smith"
    #])

#Some courses do not have prerequisites
    boolQuery_h =  any ([ True
        for c in course
        if all([
          c['cno'] != p['cno'] or
          c['dcode'] != p['dcode']
        for p in prereq])
    ])

#All classes offered this semester have prerequisites.

    boolQuery_i = any([True
                    for c in class_
                    for p in prereq
                    if not(
                    c["dcode"] == p["dcode"] and
                    c["cno"] == p["cno"]
                    )])
    # coursesWPrereq = ([
    # { 'dcode':c['dcode'],'cno':c['cno']}
    #  for c in class_
    #  for p in prereq
    #  if c['dcode'] == p['dcode'] and c['cno'] == p['cno']
    # ])
    #
    # boolQuery_i = all ([ True
    #          for cl in class_
    #          for cwp in coursesWPrereq
    #          if cl["dcode"]== cwp["dcode"] and
    #          cl["cno"]== cwp["cno"]
    # ])
    #
    # try2=[ True
    #          for cl in class_
    #          for cwp in coursesWPrereq
    #          if cl["dcode"]== cwp["dcode"] and
    #          cl["cno"]== cwp["cno"]
    # ]

    # print("####################",try2)

#Some students received only grades “A” or “B” in every course they have taken (must appear in Transcripts)
    boolQuery_j = any([True
                    for s in student
                    if not(any([
                    (t["grade"] == "C" or
                    t["grade"] == "F") and
                    t["ssn"] == s["ssn"]
                    for t in transcript]))
    ])

#All students currently enrolled in classes taught by professor Brodsky (i.e., the name is "Brodsky" in faculty), major in “CS”

    def brodskyTeaches(c):
        return any([ f["ssn"] == c["instr"] and f["name"]=="Brodsky"
                for f in faculty
                for c in class_
        ])

    withCSMajor = [ c
                    for s in student
                    for e in enrollment
                    for c in class_
                    if (
                    s["ssn"] == e["ssn"] and
                    e["class"] == c["class"] and
                    s["major"] == "CS")
                    ]

    boolQuery_k = all ([ brodskyTeaches(c)
                    for c in withCSMajor
            ])

#Some students who are currently enrolled in classes taught by professor Brodsky major in “CS”
    def brodskyTeaches(c):
        return any([ f["ssn"]==c["instr"] and f["name"]=="Brodsky"
                for f in faculty
                for c in class_
        ])

    withCSMajor = [ c
                    for s in student
                    for e in enrollment
                    for c in class_
                    if (
                    s["ssn"] == e["ssn"] and
                    e["class"] == c["class"] and
                    s["major"] == "CS")


                    ]

    boolQuery_l = any([ brodskyTeaches(c)
                    for c in withCSMajor
            ])
# # Boolean: Professor Brodsky teaches all classes in which "Tom Smith" is enrolled

# def brodskyTeaches(c): returns any classes that has faculty name brodsky
#            return any([ f["ssn"]==c["instr"] and f["name"]=="Brodsky"
#                    for f in faculty
#            ])
#        classesWTom = { c : returns classes taken by tom
#                        for c in class_
#                        for e in enrollment
#                        for s in student
#                        if c["class"]==e["class"]
#                        if e["ssn"]==s["ssn"]
#                        if s["name"]=="Tom Smith"
#        }
#q4 = all([ brodskyTeaches(c)
#                for c in classesWTom
#        ])

#q3_with_ALL = all([enrolledIn(c) for c in mathClasses])


    # data queries
    # replace the placeholder answers with Python comprehensions that correctly answer each corresponding query

    # helper functions

#All students { ssn: ..., name: ..., major: ..., status: ...} who have taken the course “cs530” (must be in transcripts)
    dataQuery_a = [
        { "ssn": s["ssn"], "name": s["name"], "major": s["major"], "status": s["status"]}
        for s in student
        if s["major"] == "CS"
        if any([
             ( t["ssn"] == s["ssn"] and
                t["cno"] == 530)
             for t in transcript
        ])
        ]
    dataQuery_a.sort(key=lambda t: t["ssn"])
    
    # dataQuery_a = [
    #     { "ssn": s["ssn"],"name": s["name"]}
    #     for s in student
    #     if s["name"]=="John Smith"
    #     if any([
    #     (s["ssn"] == t["ssn"] and
    #     t["dcode"] == "CS" and
    #     t["cno"] == 530)
    #     for t in transcript
    #     ])
    # ]
    dataQuery_a.sort(key=lambda t: t["ssn"])
#All students { ssn: ..., name: ..., major: ..., status: ...} named “John” (i.e., name = "John" in student) who have taken the course “CS 530” (must be in transcripts)
    dataQuery_b =  [
        { "ssn": s["ssn"], "name": s["name"], "major": s["major"], "status": s["status"]}
        for s in student
        if s["name"] == "John"
        if any([
            (t["ssn"] == s["ssn"] and
            t["dcode"] == "CS" and
            t["cno"] == 530)
            for t in transcript
        ])
    ]
    dataQuery_b.sort(key=lambda t: t["ssn"])

#All students { ssn: ..., name: ..., major: ..., status: ...} who satisfied all prerequisites each class they are enrolled in.
    dataQuery_c =  [s
    for s in student
    if not(any([e["class"] == c["class"] and
                e["ssn"] == s["ssn"] and
                not(checkAllPrereq(s, c["dcode"], c["cno"] ))
                for e in enrollment
                for c in class_]))]
    dataQuery_c.sort(key=lambda t: t["ssn"])

#All students { ssn: ..., name: ..., major: ..., status: ...} who are enrolled in a class for which they have not satisfied all its prerequisites.
    dataQuery_d =  [s
        for s in student
        if any([
                e["class"] == c["class"] and
                e["ssn"] == s["ssn"]  and
                not( checkAllPrereq(s, c["dcode"], c["cno"] ))
                for e in enrollment
                for c in class_])]
    dataQuery_d.sort(key=lambda t: t["ssn"])

#All students { ssn: ..., name: ..., major: ..., status: ...} named “John” who are enrolled in a class for which they have not satisfied all its prerequisites.
    dataQuery_e = [s
        for s in dataQuery_d
        if s["name"]=="John"]
    dataQuery_e.sort(key=lambda t: t["ssn"])

#All courses {dcode: …, cno: ….} that do not have prerequisites
    dataQuery_f = [ { 'dcode':c['dcode'],'cno':c['cno']}
    for c in course
    if all([
      c['cno'] != p['cno'] or
      c['dcode'] != p['dcode']
    for p in prereq]) ]
    dataQuery_f.sort(key=lambda t: (t["dcode"],t["cno"]))

#All courses {dcode: …, cno: ….} that do have some prerequisites
#convert the result into a set to eliminate duplicates
    def unique(a):
        seen = set()
        new_l = []
        for d in a:
            t = tuple(d.items())
            if t not in seen:
                seen.add(t)
                new_l.append(d)
        return new_l

    dataQuery_g = unique([ { 'dcode':c['dcode'],'cno':c['cno']}
     for c in course
     for p in prereq
     if c['dcode'] == p['dcode'] and
     c['cno'] == p['cno']
    ])
    dataQuery_g.sort(key=lambda t: (t["dcode"],t["cno"]))




#All classes {class: ..., dcode: ..., cno: ..., instr: ...} offered this semester that have prerequisites.
#convert the output to be a set to eliminate duplicates
    def unique(a):
        seen = set()
        new_l = []
        for d in a:
            t = tuple(d.items())
            if t not in seen:
                seen.add(t)
                new_l.append(d)
        return new_l

    dataQuery_h = unique([c
    for c in class_
    for x in dataQuery_g
    if any([c["dcode"]== x["dcode"] and
            c["cno"]== x["cno"]])
            ])
    dataQuery_h.sort(key=lambda t: t["class"])

#All students { ssn: ..., name: ..., major: ..., status: ...} who received only grades “A” or “B” in every course they have taken (must appear in Transcripts)
    dataQuery_i = [s
    for s in student
    if not(any([(t["grade"] == "C" or
                t["grade"] == "F") and
                t["ssn"] == s["ssn"]
                for t in transcript])
                )]
    dataQuery_i.sort(key=lambda t: t["ssn"])

#All CS students { ssn: ..., name: ..., major: ..., status: ...} who are currently enrolled in a class taught by professor Brodsky (name = “Brodsky” in faculty).
    dataQuery_j = [ s
    for s in student
    if s["major"] == "CS"
    if any([e["class"] == c["class"] and
            e["ssn"] == s["ssn"] and
            f["name"] == "Brodsky" and
            c["instr"] == f["ssn"]
            for f in faculty
            for c in class_
            for e in enrollment
    ]) ]
    dataQuery_j.sort(key=lambda t: t["ssn"])



    return({
        "boolQuery_a": boolQuery_a,
        "boolQuery_b": boolQuery_b,
        "boolQuery_c": boolQuery_c,
        "boolQuery_d": boolQuery_d,
        "boolQuery_e": boolQuery_e,
        "boolQuery_f": boolQuery_f,
        "boolQuery_g": boolQuery_g,
        "boolQuery_h": boolQuery_h,
        "boolQuery_i": boolQuery_i,
        "boolQuery_j": boolQuery_j,
        "boolQuery_k": boolQuery_k,
        "boolQuery_l": boolQuery_l,
        "dataQuery_a": dataQuery_a,
        "dataQuery_b": dataQuery_b,
        "dataQuery_c": dataQuery_c,
        "dataQuery_d": dataQuery_d,
        "dataQuery_e": dataQuery_e,
        "dataQuery_f": dataQuery_f,
        "dataQuery_g": dataQuery_g,
        "dataQuery_h": dataQuery_h,
        "dataQuery_i": dataQuery_i,
        "dataQuery_j": dataQuery_j
    })
